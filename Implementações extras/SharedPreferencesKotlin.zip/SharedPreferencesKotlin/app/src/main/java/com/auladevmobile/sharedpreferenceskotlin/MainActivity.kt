package com.auladevmobile.sharedpreferenceskotlin

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var edtTxt : EditText
    private lateinit var btnGravar : Button
    private lateinit var btnLer : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        edtTxt = findViewById(R.id.caixatxt)
        btnGravar = findViewById(R.id.btnGravar)
        btnLer = findViewById(R.id.btnLer)

        btnGravar.setOnClickListener {

            val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return@setOnClickListener
            with (sharedPref.edit()) {
                putString("nome", edtTxt.text.toString()) //insere o texto digitado pelo usuário no EditText sob a chave "nome"
                apply()
            }

        }

        btnLer.setOnClickListener {

            val sharedPref = this.getPreferences(Context.MODE_PRIVATE) ?: return@setOnClickListener

            val nome: String? = sharedPref.getString("nome","valor_padrao") //recupera o valor associado à chave "nome" no arquivo
                                                                            //o texto "valor_padrao" será retornado se nenhum texto for encontrado

            //exibe o texto lido do arquivo em forma de mensagem Toast
            Toast.makeText(applicationContext, nome, Toast.LENGTH_LONG).show()
        }

    }
}